# my views
from django.http import HttpResponse


def homepage(request):
    s = '''
    <a href="student">Students</a>
    <br>
    <br>
    <br>
    <a href="course">Courses</a>
    <br>
    <br>
    <br>
    <a href="enrollment">Enrollments</a>
    
    '''
    return HttpResponse(s)
