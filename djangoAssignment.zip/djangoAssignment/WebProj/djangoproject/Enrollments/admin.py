from django.contrib import admin
from Enrollments.models import Enrollment

admin.site.register(Enrollment)
