from django.http import Http404
from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import CreateView, DeleteView, UpdateView, DetailView ,ListView

from .models import Enrollment
from django.core.exceptions import ObjectDoesNotExist
from .forms import EnrollmentForm


class create(CreateView):
    model = Enrollment
    form_class = EnrollmentForm
    template_name = 'Enrollments/create.html'
    success_url = '/enrollment'


class delete(DeleteView):
    model = Enrollment
    template_name = 'Enrollments/delete.html'
    success_url = '/enrollment'


class update(UpdateView):
    model = Enrollment
    form_class = EnrollmentForm
    template_name = 'Enrollments/update.html'
    success_url = '/enrollment'


class detailView(DetailView):
    model = Enrollment
    template_name = 'Enrollments/detailView.html'


class listView(ListView):
    model = Enrollment
    template_name = 'Enrollments/listView.html'
    paginate_by = 5

