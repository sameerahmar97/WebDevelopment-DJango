from django.contrib import admin
from Courses.models import Course

admin.site.register(Course)
