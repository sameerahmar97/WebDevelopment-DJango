from django.contrib import admin
from Students.models import Student

admin.site.register(Student)
